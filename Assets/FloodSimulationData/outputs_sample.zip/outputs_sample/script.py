import rasterio
import argparse
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import numpy as np

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-path", type=str, help="Path to data", required=True)
    args = parser.parse_args()

    src = rasterio.open(args.data_path, mode='r')
    data = src.read(1)

    masked_matrix = np.ma.masked_where(data == -9999.0, data)
    cmap_values = plt.cm.Blues
    cmap_values.set_bad('gray')

    norm = plt.Normalize(vmin=np.min(data[data != -9999.0]), vmax=np.max(data[data != -9999.0]))

    # Plot
    plt.imshow(masked_matrix, cmap=cmap_values, norm=norm, interpolation='nearest')
    plt.colorbar()
    plt.show()


if __name__ == "__main__":
    data = main()